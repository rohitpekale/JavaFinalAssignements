package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJpaToRetrieveDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJpaToRetrieveDataApplication.class, args);
	}

}
