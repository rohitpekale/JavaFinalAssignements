package com.question10Lists;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class SecondLargestAndSmallest {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements: ");
        int count = scanner.nextInt();

        System.out.println("Enter the elements:");
        for (int i = 0; i < count; i++) {
            int num = scanner.nextInt();
            numbers.add(num);
        }

        if (numbers.size() < 2) {
            System.out.println("List should have at least 2 elements.");
            return;
        }

        Collections.sort(numbers);

        int secondSmallest = numbers.get(1);
        int secondLargest = numbers.get(numbers.size() - 2);

        System.out.println("Second smallest element: " + secondSmallest);
        System.out.println("Second largest element: " + secondLargest);
    }
}