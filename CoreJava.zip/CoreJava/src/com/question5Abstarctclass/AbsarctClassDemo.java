package com.question5Abstarctclass;
//   Abstract Class:
//   An abstract class in object-oriented programming serves as a blueprint for subclasses to inherit from.
//   It can contain a mixture of implemented and abstract methods, as well as member variables
//  
// * Key Points:
//  An abstract class can have constructors, member variables, and implemented methods.
//  It can also have abstract methods, which are declared but not implemented.
//  Subclasses of an abstract class must provide implementations for all abstract methods.
//  An abstract class cannot be instantiated; it can only be used as a superclass for other classes.

abstract class Display {

	protected String msg; // instance variable

	public Display(String msg) { // parameterized constructor
		this.msg = msg;
	}

	public void display() { // concrete method having its implementation.

		System.out.println("method called in parent class...Displaying my Name in parent:: " + msg);
	}

	abstract void watch(); // abstract method which not have its implementation.
}

class MyName extends Display { // class extending abstract class

	public MyName(String msg) { // Parameterized constructor
		super(msg);
	}

	@Override
	void watch() { // overriding method of parent abstract class

		System.out.println("method overriding...called in child...Displaying my Name in child:: " + msg);
	}
}

public class AbsarctClassDemo {

	public static void main(String[] args) {

		MyName m = new MyName("Rohit");
		m.display();
		m.watch();
	}
}
