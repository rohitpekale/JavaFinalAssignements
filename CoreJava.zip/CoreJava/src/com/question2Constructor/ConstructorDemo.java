package com.question2Constructor;

class Parent {
	public Parent() {
		System.out.println("Parent class Constructor called...");
	}
}

class Child extends Parent {
	public Child() {
		super(); // Invoking parent class constructor
		System.out.println("Child class constructor called...");
	}
}

public class ConstructorDemo {

	public static void main(String[] args) {

		Child ch = new Child(); // creating object of child class.

	}

}
//  Constructor Explanation ->
//
//  1. Constructors are special methods used to initialize objects of a class. 
//  2. They have the same name as the class and do not have a return type, not even void.
//  3. In Java, a constructor can invoke another constructor within the same class using the this() keyword,
//     or invoke a constructor of the parent class using the super() keyword.
//  4. When a child class is created, its constructor is called automatically. If the child class constructor
//     does not explicitly invoke a parent class constructor using super(),the default no-argument constructor
//     of the parent class is called implicitly.
//  5. If you want to invoke a specific parent class constructor from the child class, you can use the super()
//     keyword with appropriate arguments to match the parent class constructor's parameters.





