package com.demo.bcrypt;

public class BCryptPasswordEncoder {

	public String encode(String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
