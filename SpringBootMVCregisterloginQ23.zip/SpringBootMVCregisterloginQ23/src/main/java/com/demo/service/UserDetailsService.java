package com.demo.service;

import com.demo.entity.User;

public interface UserDetailsService {

	  public User loadUserByUsername(String username) ;
}
