package com.question9ProducerConsumer;
import java.util.LinkedList;
import java.util.Queue;

class ProducerConsumer {
    private static final int MAX_SIZE = 10; // Maximum size of the queue
    private static final int MAX_NUMBERS = 100; // Number of random numbers to generate

    private Queue<Integer> queue = new LinkedList<>();

    public static void main(String[] args) {
        ProducerConsumer pc = new ProducerConsumer();
        Thread producerThread = new Thread(pc::produce);
        Thread consumerThread = new Thread(pc::consume);

        producerThread.start();
        consumerThread.start();

        try {
            producerThread.join();
            consumerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private synchronized void produce() {
        for (int i = 0; i < MAX_NUMBERS; i++) {
            while (queue.size() == MAX_SIZE) {
                try {
                    wait(); // Wait if the queue is full
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            int number = (int) (Math.random() * 100); // Generate a random number
            queue.offer(number); // Add the number to the queue
            System.out.println("Produced: " + number);
            notify(); // Notify the consumer thread that a number is added
        }
    }

    private synchronized void consume() {
        int sum = 0;
        for (int i = 0; i < MAX_NUMBERS; i++) {
            while (queue.isEmpty()) {
                try {
                    wait(); // Wait if the queue is empty
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            int number = queue.poll(); // Remove a number from the queue
            sum += number;
            System.out.println("Consumed: " + number);
            notify(); // Notify the producer thread that a number is consumed
        }

        System.out.println("Sum of numbers: " + sum);
    }
}
