package com.question8threads;

class PrintEvenThread extends Thread {
	public void run() {
		for (int i = 0; i <= 10; i = i + 2) {
			System.out.println("Even Numbers are :: " + i);
		}
	}
}

class PrintOddThread extends Thread {
	public void run() {
		for (int i = 1; i <= 10; i = i + 2) {
			System.out.println("odd numbers :: " + i);
		}

	}
}

public class MultiThreadingDemo {

	public static void main(String[] args) {

		Thread t1 = new PrintEvenThread();
		t1.start();

		Thread t2 = new PrintOddThread();
		t2.start();

	}

}
