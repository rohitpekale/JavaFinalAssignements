package com.question6streamAPI;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

//  In this example, we have a list of numbers (numbers) that we want to sort and filter. 
//  To perform these operations, we use the Stream API methods sorted() and filter().
//
//  The sorted() method sorts the numbers in ascending order.
//  We then convert the stream back to a list using the toList() method. 
//  The sorted numbers are stored in the sortedNumbers list, which we then print using a forEach loop.
//
//  The filter() method is used to keep only the even numbers from the original list. 
//  Here, we use a lambda expression (n -> n % 2 == 0) as the filter criteria to check if a number is even. 
//  The filtered numbers are stored in the filteredNumbers list, which we also print using a forEach loop.
//
//  When you run this program, you will see the sorted numbers and the filtered numbers (even numbers)
//  printed to the console.



public class StreamExample {

	public static void main(String[] args) {
	
		//Sample data set
		List<Integer> listOfNumbers=Arrays.asList(1,3,6,2,7,9,4,10,5,8);
		
		//Sorting number using stream	
		List<Integer> sortingNumbers=listOfNumbers.stream()
				.sorted()
				.collect(Collectors.toList());
		System.out.println("Sorted Numbers :: ");
		sortingNumbers.forEach(System.out::println);
		
		
		//Filtering data using stream.
		List<Integer> filterNumbers=listOfNumbers.stream()
				
				.filter(n->n%2==0)
				.sorted()
				.collect(Collectors.toList());
		System.out.println("Filter number as Even Numbers :: ");
		filterNumbers.forEach(System.out::println);
		
		
		
	}

}
