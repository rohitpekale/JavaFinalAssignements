package com.question3exceptionhandling;

import java.util.Scanner;

public class ExceptionHandlingDemo {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in); // Scanner to read integer input from user.
		System.out.println("Enter the Integer");

		try {
			int a = sc.nextInt();
			if (a < 0) {
				throw new NegativeNumberException("negative numbers are not allowed..");
				// if negative number entered we throw Custom Exception.
			}
			System.out.println("Number entered :: " + a);

		}

		catch (NegativeNumberException e) {
			System.out.println("Exception caught :: " + e.getMessage());
		}

		catch (Exception e) {
			System.out.println("Error occured :: " + e.getMessage());
		}

	}
}

class NegativeNumberException extends Exception { // Custom exception

	private static final long serialVersionUID = 1L;

	public NegativeNumberException(String msg) {
		super(msg);
	}
}
