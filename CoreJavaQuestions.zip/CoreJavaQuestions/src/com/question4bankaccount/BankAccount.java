package com.question4bankaccount;

import java.util.Scanner;

public class BankAccount {

	private double balance; // Instance Variable

	public BankAccount(double balance) { // parameterized constructor.
		this.balance = balance;
	}

	public double deposit(double amount) { // method to deposit money.
		if (amount > 0) {
			balance += amount;
		} else {
			System.out.println("Inavlid amount");
		}
		return balance;
	}

	public double withdraw(double amount) { // method to withdraw money.
		if (amount > 0) {

			if (balance > amount) {
				balance -= amount;
			} else {
				System.out.println("Insufficient balance..");
			}

		} else {
			System.out.println("Invalid amount");
		}
		return balance;
	}

	public double getBalance() {
		return balance;
	}

	public static void main(String[] args) {

		BankAccount bank = new BankAccount(0.0);

		Scanner sc = new Scanner(System.in);

		boolean exit =false;
		while(!exit) {
		System.out.println("Welcome to MyBank...");
		System.out.println("1. Check balance ::  ");
		System.out.println("2. Deposite balance ");
		System.out.println("3. Withdraw balance ");
		System.out.println("4. Exit");
		System.out.println("Choose the Option:: ");

		int options = sc.nextInt();
		switch (options) {
		case 1:
			System.out.println("My Available balance :: " + bank.getBalance());
			break;

		case 2:
			System.out.println("Enter the amount to Deposite :: ");
			
			double depositeAmount=sc.nextDouble();

			bank.deposit(depositeAmount);
			
			break;
			
		case 3:
			System.out.println("Enter the amount to Withdraw :: ");
			
			double withdrawMoney=sc.nextDouble();
			bank.withdraw(withdrawMoney);
			break;
			
		case 4:
			System.out.println("Exit...");
			exit=true;
			break;
			
		default:
			System.out.println("Invalid option select...");
		}
		System.out.println();
		System.out.println("***********");
		System.out.println();
	  }
	
	System.out.println("Thanks for using MyBank ....");
	sc.close();
	}
}
