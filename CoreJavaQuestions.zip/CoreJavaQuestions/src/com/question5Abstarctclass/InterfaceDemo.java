package com.question5Abstarctclass;

//  Interface:
//   An interface, unlike an abstract class, only contains method declarations and constant definitions. 
//   It defines a contract that classes can implement, specifying the methods they must provide
//
//  Key Points:
//
//   An interface only contains method signatures; it does not provide implementations.
//   A class can implement multiple interfaces.
//   Implementing an interface requires providing implementations for all its methods.
//   Interfaces are used to achieve multiple inheritance-like behavior in Java.
//
//  Difference between Abstract class and Interfaces ::
//   Abstract classes can have constructors, member variables, and implemented methods, while interfaces cannot.
//   Subclasses extend abstract classes, whereas classes implement interfaces.
//   A class can only extend one abstract class, but it can implement multiple interfaces.
//   Abstract classes allow code reuse through inheritance, while interfaces promote code decoupling and achieve polymorphism.



interface Shape{
	
	 void calculateArea();      //by default methods are public, static, final.
	void calculatePerimeter();  
	
}

class Circle implements Shape{

	@Override
	public void calculateArea() {
		System.out.println("Calculating Area of Circle...");
	}

	@Override
	public void calculatePerimeter() {
		System.out.println("Calculating perimeter of Circle...");
	}
	
}

class Triangle implements Shape{
	
	public void calculateArea() {
		System.out.println("Calculating Area of Triangle...");
	}
	
	public void calculatePerimeter() {
		System.out.println("Calculating perimeter of Triangle...");
	}
}

public class InterfaceDemo {

	public static void main(String[] args) {
	
		Shape s1=new Circle();
		s1.calculateArea();
		s1.calculatePerimeter();
		
		System.out.println("*************");
		
		Shape s2=new Triangle();
		s2.calculateArea();
		s2.calculatePerimeter();
	}

}
